<footer class="bg-white py-4">
        <div class="max-w-7xl mx-auto text-center">
            <p class="text-gray-600">© 2023 SafeSpace. All rights reserved.</p>
        </div>
</footer>
