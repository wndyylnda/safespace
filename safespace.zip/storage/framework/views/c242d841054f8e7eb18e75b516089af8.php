<footer class="bg-white py-4">
        <div class="max-w-7xl mx-auto text-center">
            <p class="text-gray-600">© 2023 SafeSpace. All rights reserved.</p>
        </div>
</footer>
<?php /**PATH C:\laragon\www\safespace\resources\views/partials/footer.blade.php ENDPATH**/ ?>